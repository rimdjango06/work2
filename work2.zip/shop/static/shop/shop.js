/* shop/static/shop/shop.js */
console.log("shop/static/shop/shop.js 파일을 로드했습니다.");
