from django.contrib import admin
from shop.models import Item

admin.site.register(Item)