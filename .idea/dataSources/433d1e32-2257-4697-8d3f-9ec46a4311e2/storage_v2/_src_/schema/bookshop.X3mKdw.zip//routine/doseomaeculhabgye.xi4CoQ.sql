create procedure 도서매출합계(IN from_m varchar(255), IN to_m varchar(255))
  BEGIN
    SELECT 고객.이름 AS 고객이름, FORMAT(SUM(도서.판매단가 * 판매내역.수량), 0) AS 판매금액
    FROM 고객 INNER JOIN 판매주문 ON 고객.아이디 = 판매주문.고객아이디
              INNER JOIN 판매내역 ON 판매주문.판매연번 = 판매내역.주문연번
              INNER JOIN 도서 ON 판매내역.도서연번 = 도서.연번
    WHERE 주문일자 >= '2018-01-01' AND 주문일자 <= '2018-12-31'
    GROUP BY 고객아이디
    HAVING SUM(도서.판매단가 * 판매내역.수량) >= from_m AND SUM(도서.판매단가 * 판매내역.수량) <= to_m
    ORDER BY 판매금액 DESC;
END;

